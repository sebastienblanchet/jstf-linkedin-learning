const shape = [4,2];

const data = tf.tensor([4,6,5,9,13,25,1, 57], shape);

data.print();
