import * as tf from '@tensorflow/tfjs';

const model = await tf.loadModel('https://tfjs_artifacts/model.json');